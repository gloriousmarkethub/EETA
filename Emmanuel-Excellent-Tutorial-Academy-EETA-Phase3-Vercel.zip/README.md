# Emmanuel Excellent Tutorial Academy (EETA) — Phase 3

Vite + React + Supabase starter with course catalog, student dashboard, tutor applications, bookings, and Paystack checkout wired to a server-side Supabase Edge Function.

## Local setup
1. Install Node.js (LTS).
2. Copy `.env.example` to `.env.local`.
3. Set `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`, and `VITE_PAYSTACK_PUBLIC_KEY`.
4. Run `npm install`, then `npm run dev`.
5. Run `npm run build` before deployment.

## Vercel deployment
Import this folder/repository into Vercel. Framework: Vite. Build command: `npm run build`. Output directory: `dist`. Add the three `VITE_...` variables under Project Settings → Environment Variables, for Production and Preview, then redeploy. `vercel.json` supports React Router page refreshes.

## Supabase requirements
- Ensure the database has `courses`, `lessons`, `enrollments`, and `lesson_progress` tables as expected by the app.
- Run `supabase/phase3.sql` in the Supabase SQL Editor if those enrollment policies/indexes have not already been applied.
- The deployed Edge Function `verify-paystack-payment` must verify the transaction with Paystack using the server-side `PAYSTACK_SECRET_KEY`, validate the course amount/currency and signed-in user, and only then mark the enrollment paid.
- Set `PAYSTACK_SECRET_KEY` as an Edge Function secret in Supabase. NEVER place the secret key or Supabase service-role key in a `VITE_` variable or browser code.

## Admin account
After registering the intended admin account, run this SQL in Supabase SQL Editor, replacing the email:
`update public.profiles set role='admin' where email='YOUR-ADMIN-EMAIL@example.com';`

## Important
This ZIP is deployment-ready source, not a claim that your Vercel site is already live. Payment verification depends on the server-side Edge Function secret and its implementation being correctly configured.
