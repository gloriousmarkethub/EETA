import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route, Link, useNavigate, useParams } from "react-router-dom";
import { createClient } from "@supabase/supabase-js";
import { BookOpen, Users, CalendarDays, ShieldCheck, LogOut, LayoutDashboard, Plus, Trash2, CheckCircle, XCircle, GraduationCap, CreditCard, PlayCircle } from "lucide-react";
import "./styles.css";

const supabase = createClient(import.meta.env.VITE_SUPABASE_URL || "", import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || "");
const money = n => new Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN", maximumFractionDigits: 0 }).format(Number(n || 0));

function useAuth() {
  const [s, setS] = useState({ user: null, profile: null, loading: true });
  useEffect(() => {
    let alive = true;
    const load = async session => {
      const user = session?.user || null;
      let profile = null;
      if (user) profile = (await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle()).data || null;
      if (alive) setS({ user, profile, loading: false });
    };
    supabase.auth.getSession().then(({ data }) => load(data.session));
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, session) => { load(session); });
    return () => { alive = false; subscription.unsubscribe(); };
  }, []);
  return s;
}
function Guard({ children, admin = false }) {
  const { user, profile, loading } = useAuth();
  if (loading) return <div className="center">Loading your EETA account…</div>;
  if (!user) return <div className="center"><h2>Please sign in</h2><Link className="btn" to="/login">Login</Link></div>;
  if (admin && profile?.role !== "admin") return <div className="center"><h2>Admin access required</h2><Link to="/dashboard">Back to dashboard</Link></div>;
  return children;
}
function Layout({ children }) {
  const { user, profile } = useAuth(), nav = useNavigate();
  async function out() { await supabase.auth.signOut(); nav("/"); }
  return <><header><Link className="brand" to="/"><span className="logo">E</span>EETA</Link><nav>
    <Link to="/">Home</Link><Link to="/subjects">Subjects</Link><Link to="/courses">Courses</Link><Link to="/tutors">Tutors</Link>
    {user && <Link to="/dashboard">Dashboard</Link>}{profile?.role === "admin" && <Link to="/admin">Admin</Link>}
    {user ? <button className="linkbtn" onClick={out}><LogOut size={16}/> Logout</button> : <Link className="btn small" to="/login">Login</Link>}
  </nav></header><main>{children}</main><footer>© {new Date().getFullYear()} Emmanuel Excellent Tutorial Academy (EETA)</footer></>;
}
const subjects = ["Mathematics", "English Language", "Physics", "Chemistry", "Biology", "Computer Studies"];
function Home() { return <section className="hero"><div><span className="pill">EETA • Learn • Grow • Excel</span><h1>Quality tutoring for a brighter academic future.</h1><p>Learn at your pace with structured courses, qualified tutors and a supportive academic community.</p><div className="actions"><Link className="btn" to="/courses">Explore courses</Link><Link className="btn secondary" to="/register">Create an account</Link></div></div><div className="card heroCard"><GraduationCap size={48}/><h2>Emmanuel Excellent Tutorial Academy</h2><p>Students • Parents • Tutors • Administration</p><div className="feature"><BookOpen/> Courses and lessons</div><div className="feature"><CreditCard/> Secure payment workflow</div><div className="feature"><Users/> Tutor support</div></div></section>; }
function Subjects() { return <div className="page"><h1>Subjects</h1><p className="muted">Choose a subject to strengthen your understanding.</p><div className="grid">{subjects.map(s=><div className="card" key={s}><BookOpen/><h3>{s}</h3><p>Academic tutoring and learning support.</p></div>)}</div></div>; }
function Auth({ register = false }) {
  const nav = useNavigate(); const [name, setName] = useState(""), [email, setEmail] = useState(""), [password, setPassword] = useState(""), [role, setRole] = useState("student"), [msg, setMsg] = useState("");
  async function submit(e) {
    e.preventDefault(); setMsg("Processing…");
    if (register) {
      const { error } = await supabase.auth.signUp({ email, password, options: { data: { full_name: name, role } } });
      setMsg(error?.message || "Registration submitted. Check your email if confirmation is enabled.");
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setMsg(error.message); else nav("/dashboard");
    }
  }
  return <div className="auth"><form className="card" onSubmit={submit}><h1>{register ? "Create your EETA account" : "Welcome back"}</h1>{register && <input placeholder="Full name" value={name} onChange={e=>setName(e.target.value)} required/>}<input type="email" placeholder="Email address" value={email} onChange={e=>setEmail(e.target.value)} required/><input type="password" minLength="6" placeholder="Password (at least 6 characters)" value={password} onChange={e=>setPassword(e.target.value)} required/>{register && <select value={role} onChange={e=>setRole(e.target.value)}><option value="student">Student</option><option value="parent">Parent</option><option value="tutor">Tutor</option></select>}<button className="btn">{register ? "Register" : "Login"}</button>{msg && <p className="notice">{msg}</p>}<p><Link to={register ? "/login" : "/register"}>{register ? "Already registered? Login" : "New here? Create an account"}</Link></p></form></div>;
}
function Courses() {
  const [courses, setCourses] = useState([]), [loading, setLoading] = useState(true), [msg, setMsg] = useState("");
  useEffect(() => { (async()=>{ const {data,error } = await supabase.from("courses").select("*").eq("published",true).order("created_at",{ascending:false}); setCourses(data||[]); setMsg(error?.message||""); setLoading(false); })(); }, []);
  return <div className="page"><span className="pill">LEARNING LIBRARY</span><h1>Courses</h1><p className="muted">Enroll in a course to access its lessons. Paid courses open after payment is verified.</p>{loading ? <p>Loading courses…</p> : courses.length ? <div className="grid">{courses.map(c=><article className="card course" key={c.id}><div className="courseIcon"><BookOpen size={25}/></div><h2>{c.title||c.name||"EETA Course"}</h2><p>{c.description||"A guided course from EETA."}</p><div className="courseBottom"><strong>{Number(c.price||0)===0?"Free":money(c.price)}</strong><Link className="btn small" to={`/courses/${c.id}`}>View course</Link></div></article>)}</div> : <div className="card"><h3>No published courses yet</h3><p>An administrator can add and publish courses from the Admin dashboard.</p></div>}{msg && <p className="notice">{msg}</p>}</div>;
}
function loadPaystack() {
  return new Promise((resolve,reject)=>{
    if (window.PaystackPop) return resolve();
    const existing=document.querySelector('script[data-paystack="true"]');
    if(existing){ existing.addEventListener("load",resolve,{once:true}); existing.addEventListener("error",reject,{once:true}); return; }
    const s=document.createElement("script"); s.src="https://js.paystack.co/v1/inline.js"; s.dataset.paystack="true"; s.onload=resolve; s.onerror=reject; document.body.appendChild(s);
  });
}
function CourseDetail() {
  const { id }=useParams(), {user}=useAuth(); const [course,setCourse]=useState(null),[lessons,setLessons]=useState([]),[paid,setPaid]=useState(false),[loading,setLoading]=useState(true),[msg,setMsg]=useState("");
  async function refresh(){
    const c=await supabase.from("courses").select("*").eq("id",id).maybeSingle(); setCourse(c.data||null);
    if(user){ const e=await supabase.from("enrollments").select("payment_status").eq("course_id",id).eq("user_id",user.id).maybeSingle(); setPaid(e.data?.payment_status==="paid"); }
    const l=await supabase.from("lessons").select("*").eq("course_id",id).order("created_at",{ascending:true}); setLessons(l.data||[]);
    setLoading(false);
  }
  useEffect(()=>{refresh();},[id,user?.id]);
  async function enrollFree(){
    if(!user){setMsg("Please log in before enrolling.");return;}
    const {error}=await supabase.from("enrollments").upsert({user_id:user.id,course_id:id,payment_status:"paid"},{onConflict:"user_id,course_id"});
    setMsg(error?.message||"Enrollment complete."); await refresh();
  }
  async function pay(){
    if(!user){setMsg("Please log in before paying.");return;}
    const publicKey=import.meta.env.VITE_PAYSTACK_PUBLIC_KEY;
    if(!publicKey){setMsg("Paystack public key is missing. Add VITE_PAYSTACK_PUBLIC_KEY in Vercel Environment Variables.");return;}
    try {
      await loadPaystack();
      const handler=window.PaystackPop.setup({
        key:publicKey,email:user.email,amount:Math.round(Number(course.price)*100),currency:"NGN",
        ref:`EETA-${id}-${user.id}-${Date.now()}`,
        metadata:{course_id:id,user_id:user.id,custom_fields:[{display_name:"Course",variable_name:"course",value:course.title||course.name||"EETA Course"}]},
        callback:async response=>{
          setMsg("Payment received by Paystack. Verifying securely…");
          const {data:{session}}=await supabase.auth.getSession();
          const result=await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/verify-paystack-payment`,{
            method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${session?.access_token||""}`,"apikey":import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY},
            body:JSON.stringify({reference:response.reference,course_id:id})
          });
          const body=await result.json().catch(()=>({}));
          if(!result.ok||!body.success){setMsg(body.error||"Payment verification failed. Contact EETA support with your payment reference.");return;}
          setMsg("Payment verified. Your course is now unlocked."); await refresh();
        },
        onClose:()=>setMsg("Payment window closed. If you completed payment, refresh and check your dashboard.")
      }); handler.openIframe();
    } catch { setMsg("Unable to load Paystack checkout. Check your internet connection and try again."); }
  }
  if(loading)return <div className="center">Loading course…</div>;
  if(!course)return <div className="page"><h1>Course not found</h1><Link to="/courses">Back to courses</Link></div>;
  return <div className="page"><Link to="/courses">← All courses</Link><div className="courseDetail card"><span className="pill">EETA COURSE</span><h1>{course.title||course.name}</h1><p>{course.description||"Learn with EETA."}</p><div className="price">{Number(course.price||0)===0?"Free course":money(course.price)}</div>{paid?<div className="success"><CheckCircle/> You are enrolled and can access available lessons.</div>:Number(course.price||0)===0?<button className="btn" onClick={enrollFree}>Enroll for free</button>:<button className="btn" onClick={pay}><CreditCard size={18}/> Pay and unlock course</button>}{msg&&<p className="notice">{msg}</p>}</div>
    <h2>Course lessons</h2>{lessons.length?<div className="lessonList">{lessons.map((l,i)=><div className="card lesson" key={l.id}><PlayCircle/><div><b>{l.title||`Lesson ${i+1}`}</b><p>{l.is_free||paid?l.description||"Lesson available": "This lesson is locked until enrollment/payment."}</p></div>{(l.is_free||paid)&&<Link className="btn small" to={`/lessons/${l.id}`}>Open lesson</Link>}</div>)}</div>:<div className="card"><p>Lessons will appear here when added by the course administrator.</p></div>}</div>;
}
function LessonPage(){
 const {id}=useParams(),{user}=useAuth();const [lesson,setLesson]=useState(null),[msg,setMsg]=useState("");
 useEffect(()=>{(async()=>{const {data,error}=await supabase.from("lessons").select("*").eq("id",id).maybeSingle();setLesson(data||null);if(error)setMsg(error.message);})();},[id]);
 async function complete(){if(!user)return;const {error}=await supabase.from("lesson_progress").upsert({user_id:user.id,lesson_id:id,completed:true,completed_at:new Date().toISOString()},{onConflict:"user_id,lesson_id"});setMsg(error?.message||"Lesson marked complete.");}
 if(!lesson)return <div className="page"><h1>Lesson unavailable</h1>{msg&&<p>{msg}</p>}<Link to="/courses">Browse courses</Link></div>;
 return <div className="page"><Link to={`/courses/${lesson.course_id}`}>← Back to course</Link><article className="card lessonContent"><span className="pill">LESSON</span><h1>{lesson.title||"EETA Lesson"}</h1>{lesson.video_url&&<div className="videoBox"><a href={lesson.video_url} target="_blank" rel="noreferrer">Open lesson video</a><p className="muted">Video opens in a new tab.</p></div>}<div className="lessonText">{lesson.content||lesson.description||"Your tutor will provide the lesson material here."}</div><button className="btn" onClick={complete}>Mark lesson complete</button>{msg&&<p className="notice">{msg}</p>}</article></div>;
}
function Dashboard(){
 const {user,profile}=useAuth();const [enrollments,setEnrollments]=useState([]),[bookings,setBookings]=useState([]),[msg,setMsg]=useState("");
 useEffect(()=>{(async()=>{const e=await supabase.from("enrollments").select("*,courses(*)").eq("user_id",user.id).order("created_at",{ascending:false});setEnrollments(e.data||[]);const b=await supabase.from("bookings").select("*").eq("student_id",user.id).order("created_at",{ascending:false});setBookings(b.data||[]);})();},[user?.id]);
 return <div className="page"><span className="pill">STUDENT SPACE</span><h1>Your dashboard</h1><p>Welcome, {profile?.full_name||user.email}.</p><div className="grid"><div className="card stat"><BookOpen/><span>My courses</span><strong>{enrollments.length}</strong></div><div className="card stat"><CalendarDays/><span>Bookings</span><strong>{bookings.length}</strong></div><div className="card stat"><ShieldCheck/><span>Account role</span><strong>{profile?.role||"student"}</strong></div></div><h2>My enrollments</h2>{enrollments.length?<div className="grid">{enrollments.map(e=><div className="card" key={e.id}><h3>{e.courses?.title||e.courses?.name||"Course"}</h3><p>Status: <b>{e.payment_status||"pending"}</b></p>{e.payment_status==="paid"&&<Link className="btn small" to={`/courses/${e.course_id}`}>Continue learning</Link>}</div>)}</div>:<div className="card"><p>You have not enrolled in any courses yet.</p><Link className="btn" to="/courses">Browse courses</Link></div>}<h2>Bookings</h2>{bookings.length?bookings.map(b=><div className="card list" key={b.id}><span>{b.scheduled_at||"Date to be confirmed"}</span><small>{b.status||"pending"}</small></div>):<p className="muted">No tutor bookings yet.</p>}{msg&&<p className="notice">{msg}</p>}</div>;
}
function Tutors(){
 const {user}=useAuth();const [tutors,setTutors]=useState([]),[bio,setBio]=useState(""),[rate,setRate]=useState(""),[msg,setMsg]=useState("");
 useEffect(()=>{supabase.from("tutor_profiles").select("*,profiles(full_name,email)").eq("status","approved").then(({data})=>setTutors(data||[]));},[]);
 async function apply(e){e.preventDefault();if(!user){setMsg("Please login to apply as a tutor.");return;}const {error}=await supabase.from("tutor_profiles").upsert({user_id:user.id,bio,hourly_rate:Number(rate)||0,status:"pending"},{onConflict:"user_id"});setMsg(error?.message||"Tutor application submitted for admin review.");}
 return <div className="page"><h1>Find a Tutor</h1>{tutors.length?<div className="grid">{tutors.map(t=><div className="card" key={t.id}><Users/><h3>{t.profiles?.full_name||"EETA Tutor"}</h3><p>{t.bio||"Approved EETA tutor"}</p><strong>{money(t.hourly_rate)} / hour</strong></div>)}</div>:<div className="card"><p>Approved tutor profiles will appear here.</p></div>}<form className="card formCard" onSubmit={apply}><h2>Apply to become a tutor</h2><textarea value={bio} onChange={e=>setBio(e.target.value)} placeholder="Describe your qualifications and subjects" required/><input type="number" min="0" value={rate} onChange={e=>setRate(e.target.value)} placeholder="Hourly rate in NGN" required/><button className="btn">Submit application</button>{msg&&<p className="notice">{msg}</p>}</form></div>;
}
function Admin(){
 const [tab,setTab]=useState("overview"),[courses,setCourses]=useState([]),[subjectsData,setSubjectsData]=useState([]),[tutors,setTutors]=useState([]),[bookings,setBookings]=useState([]),[title,setTitle]=useState(""),[description,setDescription]=useState(""),[price,setPrice]=useState("40000"),[newSubject,setNewSubject]=useState(""),[msg,setMsg]=useState("");
 async function load(){const [c,s,t,b]=await Promise.all([supabase.from("courses").select("*").order("created_at",{ascending:false}),supabase.from("subjects").select("*").order("name"),supabase.from("tutor_profiles").select("*,profiles(full_name,email)").order("created_at",{ascending:false}),supabase.from("bookings").select("*").order("created_at",{ascending:false})]);setCourses(c.data||[]);setSubjectsData(s.data||[]);setTutors(t.data||[]);setBookings(b.data||[]);}
 useEffect(()=>{load();},[]);
 async function addCourse(e){e.preventDefault();const {error}=await supabase.from("courses").insert({title,description,price:Number(price)||0,published:false});setMsg(error?.message||"Course created as unpublished. Publish it when ready.");setTitle("");setDescription("");load();}
 async function publish(id,published){const {error}=await supabase.from("courses").update({published}).eq("id",id);setMsg(error?.message||"Course updated.");load();}
 async function addSub(e){e.preventDefault();const {error}=await supabase.from("subjects").insert({name:newSubject});setMsg(error?.message||"Subject added.");setNewSubject("");load();}
 async function tutor(id,status){const {error}=await supabase.from("tutor_profiles").update({status}).eq("id",id);setMsg(error?.message||"Tutor status updated.");load();}
 async function booking(id,status){const {error}=await supabase.from("bookings").update({status}).eq("id",id);setMsg(error?.message||"Booking status updated.");load();}
 return <div className="page"><div className="adminHead"><div><span className="pill">ADMIN CONTROL CENTER</span><h1>EETA Administration</h1></div><LayoutDashboard/></div><div className="tabs">{["overview","courses","subjects","tutors","bookings"].map(x=><button className={tab===x?"active":""} onClick={()=>setTab(x)} key={x}>{x}</button>)}</div>{msg&&<p className="notice">{msg}</p>}
 {tab==="overview"&&<div className="grid"><Stat icon={<BookOpen/>} title="Courses" value={courses.length}/><Stat icon={<Users/>} title="Tutor applications" value={tutors.length}/><Stat icon={<CalendarDays/>} title="Bookings" value={bookings.length}/></div>}
 {tab==="courses"&&<><form className="card formCard" onSubmit={addCourse}><h2>Create course</h2><input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Course title" required/><textarea value={description} onChange={e=>setDescription(e.target.value)} placeholder="Course description"/><input type="number" min="0" value={price} onChange={e=>setPrice(e.target.value)} placeholder="Price in NGN (0 = free)" required/><button className="btn"><Plus/> Create course</button></form><div className="card"><h2>Manage courses</h2>{courses.map(c=><div className="list" key={c.id}><div><b>{c.title||c.name}</b><small>{money(c.price)} • {c.published?"Published":"Unpublished"}</small></div><button className={c.published?"reject":"approve"} onClick={()=>publish(c.id,!c.published)}>{c.published?"Hide course":"Publish course"}</button></div>)}</div></>}
 {tab==="subjects"&&<div className="card"><h2>Subjects</h2><form className="row" onSubmit={addSub}><input value={newSubject} onChange={e=>setNewSubject(e.target.value)} placeholder="New subject" required/><button className="btn"><Plus/> Add</button></form>{subjectsData.map(s=><div className="list" key={s.id}><span>{s.name}</span></div>)}</div>}
 {tab==="tutors"&&<div className="card"><h2>Tutor applications</h2>{tutors.length?tutors.map(t=><div className="list" key={t.id}><div><b>{t.profiles?.full_name||"Tutor"}</b><small>{t.profiles?.email} • {t.status}</small></div><div className="actions"><button className="approve" onClick={()=>tutor(t.id,"approved")}><CheckCircle size={16}/>Approve</button><button className="reject" onClick={()=>tutor(t.id,"rejected")}><XCircle size={16}/>Reject</button></div></div>):<p>No tutor applications yet.</p>}</div>}
 {tab==="bookings"&&<div className="card"><h2>Bookings</h2>{bookings.length?bookings.map(b=><div className="list" key={b.id}><div><b>{b.scheduled_at||"Unscheduled"}</b><small>{b.status} • {b.notes||"No notes"}</small></div><div className="actions"><button className="approve" onClick={()=>booking(b.id,"confirmed")}>Confirm</button><button className="reject" onClick={()=>booking(b.id,"cancelled")}>Cancel</button></div></div>):<p>No bookings yet.</p>}</div>}
 </div>;
}
function Stat({icon,title,value}){return <div className="card stat">{icon}<span>{title}</span><strong>{value}</strong></div>}
function App(){return <Layout><Routes><Route path="/" element={<Home/>}/><Route path="/subjects" element={<Subjects/>}/><Route path="/courses" element={<Courses/>}/><Route path="/courses/:id" element={<CourseDetail/>}/><Route path="/lessons/:id" element={<Guard><LessonPage/></Guard>}/><Route path="/tutors" element={<Tutors/>}/><Route path="/login" element={<Auth/>}/><Route path="/register" element={<Auth register/>}/><Route path="/dashboard" element={<Guard><Dashboard/></Guard>}/><Route path="/admin" element={<Guard admin><Admin/></Guard>}/><Route path="*" element={<div className="page"><h1>Page not found</h1><Link to="/">Return home</Link></div>}/></Routes></Layout>}
createRoot(document.getElementById("root")).render(<BrowserRouter><App/></BrowserRouter>);
