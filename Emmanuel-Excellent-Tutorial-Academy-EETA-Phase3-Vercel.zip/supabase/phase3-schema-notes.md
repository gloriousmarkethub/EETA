# Phase 3 schema notes

The frontend expects `courses` fields `id`, `title` (or `name`), `description`, `price`, `published`, `created_at`; `lessons` fields `id`, `course_id`, `title`, `description`, `content`, `video_url`, `is_free`, `created_at`; `enrollments` fields `id`, `user_id`, `course_id`, `payment_status`, `created_at`; and `lesson_progress` fields `user_id`, `lesson_id`, `completed`, `completed_at`.

If your live schema uses different names, adjust the frontend or add a migration before launch. The payment callback is not proof of payment: the Edge Function must verify the reference directly with Paystack before marking an enrollment paid.
