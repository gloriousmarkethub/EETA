-- Run after the original EETA schema.sql
alter table public.tutor_profiles add column if not exists status text not null default 'pending' check(status in ('pending','approved','rejected'));
alter table public.tutor_profiles add column if not exists bio text;
alter table public.tutor_profiles add column if not exists hourly_rate numeric(12,2);
alter table public.bookings add column if not exists scheduled_at timestamptz;
alter table public.bookings add column if not exists notes text;
create index if not exists tutor_profiles_status_idx on public.tutor_profiles(status);
create index if not exists bookings_status_idx on public.bookings(status);
alter table public.tutor_profiles enable row level security;
alter table public.bookings enable row level security;
drop policy if exists "tutors create own profile" on public.tutor_profiles;
create policy "tutors create own profile" on public.tutor_profiles for insert with check(auth.uid()=user_id);
drop policy if exists "tutors update own profile" on public.tutor_profiles;
create policy "tutors update own profile" on public.tutor_profiles for update using(auth.uid()=user_id) with check(auth.uid()=user_id);
drop policy if exists "admins manage tutors" on public.tutor_profiles;
create policy "admins manage tutors" on public.tutor_profiles for all using(public.is_admin()) with check(public.is_admin());
drop policy if exists "students create bookings" on public.bookings;
create policy "students create bookings" on public.bookings for insert with check(auth.uid()=student_id);
drop policy if exists "students view own bookings" on public.bookings;
create policy "students view own bookings" on public.bookings for select using(auth.uid()=student_id or public.is_admin());
drop policy if exists "admins manage bookings" on public.bookings;
create policy "admins manage bookings" on public.bookings for all using(public.is_admin()) with check(public.is_admin());
drop policy if exists "public view approved tutors" on public.tutor_profiles;
create policy "public view approved tutors" on public.tutor_profiles for select using(status='approved' or auth.uid()=user_id or public.is_admin());
-- After creating your account, promote it once:
-- update public.profiles set role='admin' where email='YOUR-EMAIL@example.com';