-- EETA Phase 3 enrollment and paid-lesson access policies.
-- Review existing policies before running if you have customized your database.
alter table public.enrollments
  add constraint enrollments_user_course_unique unique (user_id, course_id);

create index if not exists enrollments_user_id_idx on public.enrollments(user_id);
create index if not exists enrollments_course_id_idx on public.enrollments(course_id);

drop policy if exists "students view own enrollments" on public.enrollments;
create policy "students view own enrollments" on public.enrollments
  for select using (auth.uid() = user_id or public.is_admin());

drop policy if exists "students create pending enrollments" on public.enrollments;
create policy "students create pending enrollments" on public.enrollments
  for insert with check (auth.uid() = user_id);

drop policy if exists "admins manage enrollments" on public.enrollments;
create policy "admins manage enrollments" on public.enrollments
  for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "published courses visible" on public.courses;
create policy "published courses visible" on public.courses
  for select using (published = true or public.is_admin());

drop policy if exists "course lessons visible" on public.lessons;
create policy "course lessons visible" on public.lessons
  for select using (
    is_free = true
    or public.is_admin()
    or exists (
      select 1 from public.enrollments e
      where e.course_id = lessons.course_id
        and e.user_id = auth.uid()
        and e.payment_status = 'paid'
    )
  );

drop policy if exists "users manage own progress" on public.lesson_progress;
create policy "users manage own progress" on public.lesson_progress
  for all using (auth.uid() = user_id)
  with check (auth.uid() = user_id);
